﻿"use client";

import React, { useEffect, useState, useCallback } from "react";
import { FiEdit } from "react-icons/fi";
import { RiDeleteBin6Line } from "react-icons/ri";
import * as RiIcons from "react-icons/ri";
import {
  getServices,
  getCounters,
  createService,
  updateService,
  deleteService,
  addServicesToCounter,
  removeServiceFromCounter,
  Counter,
  Service,
} from "@/services/admin.service";
import { FONTAWESOME_ICONS } from "@/constants/icons";
import { useToast } from "@/hooks/useToast";
import ToastContainer from "@/components/ToastContainer";
import AdminConfirmDialog from "@/components/admin/AdminConfirmDialog";
import Pagination from "./Pagination";
import AdminTableFilter from "./AdminTableFilter";
import { getSequentialTagColorStyle } from "@/lib/adminTagColors";
import "@/styles/admin-table.css";

// Helper function to get icon component from name
const getIconComponent = (iconName: string) => {
  const Icon = (RiIcons as Record<string, React.ComponentType<{ size?: number; style?: React.CSSProperties }>>)[iconName];
  return Icon || null;
};

export default function ServiceTable() {
  const PREFIX_NUMBER_MIN = 0;
  const PREFIX_NUMBER_MAX = 99;
  const { toasts, removeToast, success, error } = useToast();
  const [services, setServices] = useState<Service[]>([]);
  const [counters, setCounters] = useState<Counter[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCounterIds, setFilterCounterIds] = useState<string[]>(["all"]);
  const [filterStatuses, setFilterStatuses] = useState<string[]>(["all"]);
  const [filterPrefixNumbers, setFilterPrefixNumbers] = useState<string[]>(["all"]);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedCounters, setSelectedCounters] = useState<string[]>([]);
  const [initialCounters, setInitialCounters] = useState<string[]>([]);
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const [showStatusConfirm, setShowStatusConfirm] = useState(false);
  const [pendingStatusChange, setPendingStatusChange] = useState<
    boolean | null
  >(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [prefixNumberError, setPrefixNumberError] = useState("");
  const [formData, setFormData] = useState({
    code: "",
    name: "",
    icon: "",
    description: "",
    displayOrder: 1,
    prefixNumber: 0,
    isActive: true,
  });

  const validatePrefixNumber = (value: number) => {
    if (!Number.isInteger(value)) {
      return "Số tiền tố phải là số nguyên.";
    }

    if (value < PREFIX_NUMBER_MIN || value > PREFIX_NUMBER_MAX) {
      return `Số tiền tố phải nằm trong khoảng từ ${PREFIX_NUMBER_MIN} đến ${PREFIX_NUMBER_MAX}.`;
    }

    return "";
  };

  const fetchServices = useCallback(async () => {
    setLoading(true);
    const data = await getServices();
    setServices(data);
    setLoading(false);
  }, []);

  const fetchCounters = useCallback(async () => {
    const data = await getCounters();
    setCounters(data);
  }, []);

  useEffect(() => {
    void fetchServices();
    void fetchCounters();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleOpenModal = (service?: Service) => {
    if (service) {
      setEditingId(service._id);
      setFormData({
        code: service.code,
        name: service.name,
        icon: service.icon,
        description: service.description,
        displayOrder: service.displayOrder,
        prefixNumber: service.prefixNumber ?? 0,
        isActive: service.isActive,
      });
      setPrefixNumberError("");
      const counterIds = service.counters?.map((counter) => counter._id) || [];
      setSelectedCounters(counterIds);
      setInitialCounters(counterIds);
    } else {
      setEditingId(null);
      setFormData({
        code: "",
        name: "",
        icon: "",
        description: "",
        displayOrder: 1,
        prefixNumber: 0,
        isActive: true,
      });
      setPrefixNumberError("");
      setSelectedCounters([]);
      setInitialCounters([]);
    }
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingId(null);
    setFormData({
      code: "",
      name: "",
      icon: "",
      description: "",
      displayOrder: 1,
      prefixNumber: 0,
      isActive: true,
    });
    setPrefixNumberError("");
    setSelectedCounters([]);
    setInitialCounters([]);
  };

  const handleCounterToggle = (counterId: string) => {
    if (selectedCounters.includes(counterId)) {
      setSelectedCounters((prev) => prev.filter((id) => id !== counterId));
      return;
    }
    setSelectedCounters((prev) => [...prev, counterId]);
  };

  const handleStatusChange = (newStatus: boolean) => {
    setPendingStatusChange(newStatus);
    setShowStatusConfirm(true);
  };

  const handleConfirmStatus = () => {
    if (pendingStatusChange !== null) {
      setFormData({ ...formData, isActive: pendingStatusChange });
    }
    setShowStatusConfirm(false);
    setPendingStatusChange(null);
  };

  const handleDelete = (serviceId: string) => {
    setPendingDeleteId(serviceId);
    setShowDeleteConfirm(true);
  };

  const handlePrefixNumberChange = (value: string) => {
    const nextValue = Number(value);
    setFormData((prev) => ({
      ...prev,
      prefixNumber: nextValue,
    }));
    setPrefixNumberError(validatePrefixNumber(nextValue));
  };

  const handleConfirmDelete = async () => {
    if (pendingDeleteId) {
      try {
        await deleteService(pendingDeleteId);
        success("Xóa quầy thành công");
        fetchServices();
      } catch (err) {
        const errorMessage =
          err instanceof Error ? err.message : "Xóa quầy thất bại";
        error(errorMessage);
      }
    }
    setShowDeleteConfirm(false);
    setPendingDeleteId(null);
  };

  const handleSave = async () => {
    if (!formData.code || !formData.name) {
      error("Vui lòng nhập mã và tên quầy");
      return;
    }

    const normalizedPrefixNumber = Number(formData.prefixNumber);
    const prefixValidationMessage = validatePrefixNumber(normalizedPrefixNumber);
    if (prefixValidationMessage) {
      setPrefixNumberError(prefixValidationMessage);
      error(prefixValidationMessage);
      return;
    }
    setPrefixNumberError("");

    try {
      if (editingId) {
        await updateService(editingId, {
          ...formData,
          prefixNumber: normalizedPrefixNumber,
        });

        const removedCounterIds = initialCounters.filter(
          (counterId) => !selectedCounters.includes(counterId),
        );
        if (removedCounterIds.length > 0) {
          await Promise.all(
            removedCounterIds.map((counterId) =>
              removeServiceFromCounter(counterId, editingId),
            ),
          );
        }

        const addedCounterIds = selectedCounters.filter(
          (counterId) => !initialCounters.includes(counterId),
        );
        if (addedCounterIds.length > 0) {
          await Promise.all(
            addedCounterIds.map((counterId) =>
              addServicesToCounter(counterId, [editingId]),
            ),
          );
        }

        success("Cập nhật quầy thành công");
        fetchServices();
        fetchCounters();
        handleCloseModal();
      } else {
        const createdService = await createService({
          code: formData.code,
          name: formData.name,
          icon: formData.icon,
          description: formData.description,
          displayOrder: formData.displayOrder,
          prefixNumber: normalizedPrefixNumber,
          isActive: formData.isActive,
        });

        await Promise.all(
          selectedCounters.map((counterId) =>
            addServicesToCounter(counterId, [createdService._id]),
          ),
        );

        success("Tạo quầy thành công");
        fetchServices();
        fetchCounters();
        handleCloseModal();
      }
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Lỗi lưu quầy thất bại";
      error(errorMessage);
    }
  };

  const filteredServices = services.filter((service) => {
    const matchesSearch =
      service.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      service.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCounter =
      filterCounterIds.includes("all") ||
      service.counters?.some((counter) => filterCounterIds.includes(counter._id));
    const matchesStatus =
      filterStatuses.includes("all") ||
      (filterStatuses.includes("active") && service.isActive) ||
      (filterStatuses.includes("inactive") && !service.isActive);
    const matchesPrefix =
      filterPrefixNumbers.includes("all") ||
      filterPrefixNumbers.includes(String(service.prefixNumber ?? 0));

    return matchesSearch && matchesCounter && matchesStatus && matchesPrefix;
  });

  const counterColorMap = new Map(
    [...counters]
      .sort((a, b) => a.number - b.number || a.name.localeCompare(b.name))
      .map((counter, index) => [
        counter._id,
        getSequentialTagColorStyle(index),
      ]),
  );

  // Pagination logic
  const totalPages = Math.ceil(filteredServices.length / itemsPerPage);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const paginatedServices = filteredServices.slice(
    indexOfFirstItem,
    indexOfLastItem,
  );

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  // Reset to first page when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, filterCounterIds, filterStatuses, filterPrefixNumbers]);

  return (
    <div className="admin-table-container">
      <ToastContainer toasts={toasts} onRemoveToast={removeToast} />
      <div className="admin-table-header">
        <div className="font-bold text-2xl" style={{ color: "#003366" }}>
          QUẢN LÝ QUẦY
        </div>
        <div className="admin-table-actions">
          <AdminTableFilter
            activeCount={
              (filterCounterIds.includes("all") ? 0 : filterCounterIds.length) +
              (filterStatuses.includes("all") ? 0 : filterStatuses.length) +
              (filterPrefixNumbers.includes("all") ? 0 : filterPrefixNumbers.length)
            }
            onReset={() => {
              setFilterCounterIds(["all"]);
              setFilterStatuses(["all"]);
              setFilterPrefixNumbers(["all"]);
            }}
            sections={[
              {
                id: "service-counter",
                label: "Phòng",
                value: filterCounterIds,
                onChange: setFilterCounterIds,
                options: [
                  { label: "Tất cả phòng", value: "all" },
                  ...[...counters]
                    .sort((a, b) => a.number - b.number)
                    .map((counter) => ({
                      label: `${counter.name} (${counter.code})`,
                      value: counter._id,
                    })),
                ],
              },
              {
                id: "service-status",
                label: "Trạng thái",
                value: filterStatuses,
                onChange: setFilterStatuses,
                options: [
                  { label: "Tất cả trạng thái", value: "all" },
                  { label: "Hoạt động", value: "active" },
                  { label: "Vô hiệu", value: "inactive" },
                ],
              },
              {
                id: "service-prefix",
                label: "Mã tiền tố",
                value: filterPrefixNumbers,
                onChange: setFilterPrefixNumbers,
                options: [
                  { label: "Tất cả mã tiền tố", value: "all" },
                  ...Array.from(
                    new Set(services.map((service) => String(service.prefixNumber ?? 0))),
                  )
                    .sort((a, b) => Number(a) - Number(b))
                    .map((value) => ({
                      label: `Tiền tố ${value}`,
                      value,
                    })),
                ],
              },
            ]}
          />
          <input
            type="text"
            className="admin-table-search"
            placeholder="Tìm kiếm mã hoặc tên quầy..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button className="admin-table-btn" onClick={() => handleOpenModal()}>
            + Thêm Mới
          </button>
        </div>
      </div>
      <div className="admin-table-body">
        <table className="admin-table service-table">
          <thead>
            <tr>
              <th>Thứ tự</th>
              <th>Mã quầy</th>
              <th>Mã tiền tố</th>
              <th>Tên quầy</th>
              <th>Phòng</th>
              <th>Trạng thái</th>
              <th>Mô tả</th>
              <th>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={8} className="admin-table-loading">
                  Đang tải...
                </td>
              </tr>
            ) : paginatedServices.length > 0 ? (
              paginatedServices.map((service) => (
                <tr key={service._id}>
                  <td>{service.displayOrder}</td>
                  <td>{service.code}</td>
                  <td>
                    {service.prefixNumber ?? 0}
                  </td>
                  <td>
                    <span style={{ display: "flex", alignItems: "center" }}>
                      {service.icon &&
                        getIconComponent(service.icon) &&
                        React.createElement(getIconComponent(service.icon)!, {
                          size: 16,
                          style: { marginRight: "8px" },
                        })}
                      {service.name}
                    </span>
                  </td>
                  <td>
                    <div className="table-cell-counters">
                      {service.counters?.map((counter) => (
                        <span
                          key={counter._id}
                          className="table-cell-tag"
                          style={{
                            background:
                              counterColorMap.get(counter._id)?.background ||
                              "#dbeafe",
                            borderLeftColor:
                              counterColorMap.get(counter._id)?.border ||
                              "#2563eb",
                            color:
                              counterColorMap.get(counter._id)?.color ||
                              "#1e3a8a",
                          }}
                        >
                          {counter.name} ({counter.code})
                        </span>
                      ))}
                    </div>
                  </td>
                  <td>
                    <span
                      className={`table-cell-status ${
                        service.isActive ? "status-active" : "status-inactive"
                      }`}
                    >
                      {service.isActive ? "Hoạt động" : "Vô hiệu"}
                    </span>
                  </td>
                  <td>{service.description}</td>
                  <td>
                    <div className="table-actions">
                      <button
                        className="table-action-edit"
                        onClick={() => handleOpenModal(service)}
                      >
                        <FiEdit size={16} />
                      </button>
                      <button
                        className="table-action-delete"
                        onClick={() => handleDelete(service._id)}
                      >
                        <RiDeleteBin6Line size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={8} className="admin-table-empty">
                  Không có quầy nào.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="admin-table-footer">
        <span>
          Hiển thị {paginatedServices.length} trên tổng số {filteredServices.length}{" "}
          kết quả
        </span>
      </div>
      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={handlePageChange}
      />
      {showModal && (
        <div className="admin-modal">
          <div className="admin-modal-content">
            <button className="admin-modal-close" onClick={handleCloseModal}>
              ×</button>
            <h3 style={{ marginTop: 0, marginBottom: 20 }}>
              {editingId ? "Chỉnh Sửa Quầy" : "Thêm Quầy Mới"}
            </h3>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "30px",
              }}
            >
              {/* Left Column - Info & Status */}
              <div>
                <div className="admin-form-group">
                  <label className="admin-form-label">Mã Quầy:</label>
                  <input
                    type="text"
                    className="admin-form-input"
                    value={formData.code}
                    onChange={(e) =>
                      setFormData({ ...formData, code: e.target.value })
                    }
                    disabled={!!editingId}
                    style={{
                      backgroundColor: editingId ? "#f0f0f0" : "#fff",
                      cursor: editingId ? "not-allowed" : "text",
                      opacity: editingId ? 0.6 : 1,
                    }}
                  />
                </div>

                <div className="admin-form-group">
                  <label className="admin-form-label">Số Thứ Tự:</label>
                  <input
                    type="number"
                    className="admin-form-input"
                    value={formData.displayOrder}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        displayOrder: parseInt(e.target.value),
                      })
                    }
                  />
                </div>

                <div className="admin-form-group">
                  <label className="admin-form-label">Mã tiền tố:</label>
                  <input
                    type="number"
                    min={PREFIX_NUMBER_MIN}
                    max={PREFIX_NUMBER_MAX}
                    className="admin-form-input"
                    value={formData.prefixNumber}
                    onChange={(e) => handlePrefixNumberChange(e.target.value)}
                  />
                  {prefixNumberError ? (
                    <div
                      style={{
                        marginTop: "6px",
                        fontSize: "12px",
                        color: "#dc3545",
                      }}
                    >
                      {prefixNumberError}
                    </div>
                  ) : null}
                </div>

                <div className="admin-form-group">
                  <label className="admin-form-label">Tên Quầy:</label>
                  <input
                    type="text"
                    className="admin-form-input"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                  />
                </div>

                <div className="admin-form-group">
                  <label
                    className="admin-form-label"
                    style={{ marginBottom: "12px" }}
                  >
                    Trạng Thái:
                  </label>
                  <label className="admin-checkbox-card">
                    <input
                      type="checkbox"
                      checked={formData.isActive}
                      onChange={(e) => handleStatusChange(e.target.checked)}
                    />
                    <div>
                      <div className="admin-checkbox-card-title">
                        {formData.isActive ? "Hoạt động" : "Vô hiệu"}
                      </div>
                      <div className="admin-checkbox-card-description">
                        Bật checkbox là hoạt động, bỏ chọn là vô hiệu
                      </div>
                    </div>
                  </label>
                </div>
              </div>

              {/* Right Column - Icon & Description */}
              <div>
                <div className="admin-form-group">
                  <label className="admin-form-label">Biểu tượng</label>
                  <div
                    style={{
                      border: "1px solid #d0d0d0",
                      borderRadius: "4px",
                      padding: "12px",
                      maxHeight: "200px",
                      overflowY: "auto",
                      display: "grid",
                      gridTemplateColumns: "repeat(5, 1fr)",
                      gap: "8px",
                      marginBottom: "15px",
                    }}
                  >
                    {FONTAWESOME_ICONS.map((icon: (typeof FONTAWESOME_ICONS)[number]) => {
                      const IconComponent = getIconComponent(icon.class);
                      return (
                        <button
                          key={icon.id}
                          onClick={() =>
                            setFormData({ ...formData, icon: icon.class })
                          }
                          style={{
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            justifyContent: "center",
                            padding: "12px",
                            border:
                              formData.icon === icon.class
                                ? "2px solid #003366"
                                : "1px solid #e0e0e0",
                            borderRadius: "4px",
                            backgroundColor:
                              formData.icon === icon.class ? "#f0f7ff" : "#fff",
                            cursor: "pointer",
                            fontSize: "12px",
                            fontWeight: formData.icon === icon.class ? 600 : 400,
                            color:
                              formData.icon === icon.class ? "#003366" : "#333",
                            transition: "all 0.2s ease",
                            minHeight: "60px",
                          }}
                          title={icon.name}
                        >
                          {IconComponent ? (
                            <IconComponent
                              size={24}
                              style={{
                                color: "#000",
                                marginBottom: "4px",
                              }}
                            />
                          ) : (
                            <span style={{ fontSize: "12px", color: "#999" }}>
                              N/A
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                  <div
                    style={{
                      fontSize: "12px",
                      color: "#666",
                      marginTop: "8px",
                    }}
                  >
                    Đã chọn: <strong>{formData.icon || "Chưa chọn"}</strong>
                  </div>
                </div>

                <div className="admin-form-group">
                  <label className="admin-form-label">Mô Tả:</label>
                  <textarea
                    className="admin-form-textarea"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    style={{ minHeight: "80px" }}
                  />
                </div>
              </div>
            </div>

            <div style={{ marginTop: "20px" }}>
              <div className="admin-form-group" style={{ marginBottom: 0 }}>
                <label className="admin-form-label">Thêm quầy vào phòng đã có:</label>
                <div
                  className="admin-counter-grid"
                >
                  {counters.length === 0 ? (
                    <span style={{ color: "#999", fontSize: "14px" }}>
                      Chưa có phòng nào
                    </span>
                  ) : (
                    counters.map((counter) => (
                      <label
                        key={counter._id}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                          cursor: "pointer",
                          fontSize: "14px",
                          color: "#333",
                        }}
                      >
                        <input
                          type="checkbox"
                          checked={selectedCounters.includes(counter._id)}
                          onChange={() => handleCounterToggle(counter._id)}
                          style={{ cursor: "pointer" }}
                        />
                        <span>
                          {counter.name} ({counter.code})
                        </span>
                      </label>
                    ))
                  )}
                </div>
              </div>
            </div>

            <div className="admin-form-actions" style={{ marginTop: "30px" }}>
              <button className="submit" onClick={handleSave}>
                Cập nhật
              </button>
              <button className="cancel" onClick={handleCloseModal}>
                Hủy bỏ
              </button>
            </div>
          </div>
        </div>
      )}

      <AdminConfirmDialog
        isOpen={showStatusConfirm}
        title="Xác thực thay đổi trạng thái"
        message={`Bạn có chắc chắn muốn chuyển trạng thái quầy thành ${pendingStatusChange ? "Hoạt động" : "Vô hiệu"}?`}
        onConfirm={handleConfirmStatus}
        onCancel={() => {
          setShowStatusConfirm(false);
          setPendingStatusChange(null);
        }}
      />

      <AdminConfirmDialog
        isOpen={showDeleteConfirm}
        title="Xác nhận xóa quầy"
        message="Bạn có chắc chắn muốn xóa quầy này? Hành động này không thể hoàn tác."
        onConfirm={handleConfirmDelete}
        onCancel={() => setShowDeleteConfirm(false)}
      />
    </div>
  );
}



