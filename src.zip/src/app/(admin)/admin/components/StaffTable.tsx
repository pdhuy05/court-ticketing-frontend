"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { FiEdit, FiRepeat } from "react-icons/fi";
import { RiDeleteBin6Line } from "react-icons/ri";
import {
  assignCounterToStaff,
  Counter,
  createStaff,
  deleteStaff,
  getCounters,
  getStaff,
  Staff,
  StaffServiceInfo,
  updateStaff,
  updateStaffServices,
} from "@/services/admin.service";
import { useToast } from "@/hooks/useToast";
import { useAdminSessionGuard } from "@/hooks/useAdminSessionGuard";
import ToastContainer from "@/components/ToastContainer";
import AdminConfirmDialog from "@/components/admin/AdminConfirmDialog";
import Pagination from "./Pagination";
import AdminTableFilter from "./AdminTableFilter";
import { getSequentialTagColorStyle } from "@/lib/adminTagColors";
import "@/styles/admin-table.css";

type ApiErrorShape = {
  response?: {
    data?: {
      errors?: Record<string, string | { message?: string }>;
      message?: string;
    };
  };
  message?: string;
};

const parseApiError = (err: unknown): string => {
  const apiError = err as ApiErrorShape;
  const data = apiError?.response?.data;

  if (!data) {
    return apiError?.message || "Lỗi không xác định";
  }

  if (data.errors) {
    const firstErrorKey = Object.keys(data.errors)[0];
    const firstError = data.errors[firstErrorKey];

    if (typeof firstError === "string") {
      return firstError;
    }

    if (firstError?.message) {
      return firstError.message;
    }
  }

  return data.message || "Lỗi không xác định";
};

export default function StaffTable() {
  const { toasts, removeToast, success, error } = useToast();
  const guardSession = useAdminSessionGuard();
  const [staffList, setStaffList] = useState<Staff[]>([]);
  const [counters, setCounters] = useState<Counter[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCounterIds, setFilterCounterIds] = useState<string[]>(["all"]);
  const [filterServiceIds, setFilterServiceIds] = useState<string[]>(["all"]);
  const [filterStatuses, setFilterStatuses] = useState<string[]>(["all"]);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [showServiceModal, setShowServiceModal] = useState(false);
  const [serviceModalStaff, setServiceModalStaff] = useState<Staff | null>(null);
  const [availableServices, setAvailableServices] = useState<StaffServiceInfo[]>([]);
  const [selectedServiceIds, setSelectedServiceIds] = useState<Set<string>>(new Set());
  const [serviceModalLoading, setServiceModalLoading] = useState(false);
  const [serviceModalSaving, setServiceModalSaving] = useState(false);
  const [serviceRestrictionConfigured, setServiceRestrictionConfigured] = useState(false);
  const [formAvailableServices, setFormAvailableServices] = useState<StaffServiceInfo[]>([]);
  const [formSelectedServiceIds, setFormSelectedServiceIds] = useState<Set<string>>(new Set());
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const [formData, setFormData] = useState({
    username: "",
    password: "",
    fullName: "",
    counterId: null as string | null,
    isActive: true,
  });

  const fetchStaff = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getStaff();
      setStaffList(data);
    } catch (err) {
      if (guardSession(err)) return;
      error("Không thể tải danh sách nhân viên");
    } finally {
      setLoading(false);
    }
  }, [error, guardSession]);

  const fetchCounters = useCallback(async () => {
    try {
      const data = await getCounters();
      setCounters(data);
    } catch (err) {
      if (guardSession(err)) return;
      error("Không thể tải danh sách phòng");
    }
  }, [error, guardSession]);

  useEffect(() => {
    void fetchStaff();
    void fetchCounters();
  }, [fetchStaff, fetchCounters]);

  const mapCounterServices = (counterId: string | null) => {
    const counterServices =
      counters.find((counter) => counter._id === (counterId || ""))?.services || [];

    return counterServices.map((service) => ({
      id: service._id,
      _id: service._id,
      code: service.code,
      name: service.name,
      icon: service.icon,
      displayOrder: service.displayOrder,
    }));
  };

  const handleOpenModal = (staff?: Staff) => {
    if (staff) {
      const normalizedAvailableServices = mapCounterServices(staff.counterId?._id || null);
      const initialSelected =
        staff.serviceRestrictionConfigured && staff.assignedServices
          ? new Set(staff.assignedServices.map((service) => service.id || service._id))
          : new Set(normalizedAvailableServices.map((service) => service.id || service._id));

      setEditingId(staff._id);
      setFormData({
        username: staff.username,
        password: "",
        fullName: staff.fullName,
        counterId: staff.counterId?._id || null,
        isActive: staff.isActive,
      });
      setFormAvailableServices(normalizedAvailableServices);
      setFormSelectedServiceIds(initialSelected);
    } else {
      setEditingId(null);
      setFormData({
        username: "",
        password: "",
        fullName: "",
        counterId: null,
        isActive: true,
      });
      setFormAvailableServices([]);
      setFormSelectedServiceIds(new Set());
    }

    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingId(null);
    setFormAvailableServices([]);
    setFormSelectedServiceIds(new Set());
  };

  const handleDelete = (staffId: string) => {
    setPendingDeleteId(staffId);
    setShowDeleteConfirm(true);
  };

  const handleConfirmDelete = async () => {
    if (!pendingDeleteId) return;

    try {
      await deleteStaff(pendingDeleteId);
      success("Xóa nhân viên thành công");
      await fetchStaff();
    } catch (err) {
      error(err instanceof Error ? err.message : "Xóa nhân viên thất bại");
    } finally {
      setShowDeleteConfirm(false);
      setPendingDeleteId(null);
    }
  };

  const handleFormCounterChange = (counterId: string | null) => {
    const normalizedAvailableServices = mapCounterServices(counterId);
    setFormData((prev) => ({ ...prev, counterId }));
    setFormAvailableServices(normalizedAvailableServices);
    setFormSelectedServiceIds(
      new Set(normalizedAvailableServices.map((service) => service.id || service._id)),
    );
  };

  const handleToggleFormService = (serviceId: string) => {
    setFormSelectedServiceIds((prev) => {
      const next = new Set(prev);
      if (next.has(serviceId)) next.delete(serviceId);
      else next.add(serviceId);
      return next;
    });
  };

  const handleSave = async () => {
    if (!formData.username || !formData.fullName) {
      error("Vui lòng nhập tên đăng nhập và họ tên");
      return;
    }

    if (!editingId && !formData.password) {
      error("Vui lòng nhập mật khẩu cho nhân viên mới");
      return;
    }

    const previousCounterId = editingId
      ? staffList.find((staff) => staff._id === editingId)?.counterId?._id ?? null
      : null;

    try {
      let savedStaff: Staff;

      if (editingId) {
        if (formData.counterId && formData.counterId !== previousCounterId) {
          await assignCounterToStaff(editingId, formData.counterId);
        }

        savedStaff = await updateStaff(editingId, {
          fullName: formData.fullName,
          isActive: formData.isActive,
          password: formData.password || undefined,
          counterId: formData.counterId,
        });

        if (formData.counterId) {
          await updateStaffServices(savedStaff._id, Array.from(formSelectedServiceIds));
        }

        success("Cập nhật nhân viên thành công");
      } else {
        savedStaff = await createStaff({
          username: formData.username,
          password: formData.password,
          fullName: formData.fullName,
        });

        if (formData.counterId) {
          await assignCounterToStaff(savedStaff._id, formData.counterId);
          if (formSelectedServiceIds.size > 0) {
            await updateStaffServices(savedStaff._id, Array.from(formSelectedServiceIds));
          }
        }

        success("Tạo nhân viên thành công");
      }
    } catch (err) {
      await fetchStaff();
      error(parseApiError(err));
      return;
    }

    handleCloseModal();
    await fetchStaff();
  };

  const handleOpenServiceModal = async (staff: Staff) => {
    setServiceModalStaff(staff);
    setShowServiceModal(true);
    setServiceModalLoading(true);

    try {
      const normalizedAvailableServices = mapCounterServices(staff.counterId?._id || null);
      const initialSelected =
        staff.serviceRestrictionConfigured && staff.assignedServices
          ? new Set(staff.assignedServices.map((service) => service.id || service._id))
          : new Set(normalizedAvailableServices.map((service) => service.id || service._id));

      setAvailableServices(normalizedAvailableServices);
      setSelectedServiceIds(initialSelected);
      setServiceRestrictionConfigured(Boolean(staff.serviceRestrictionConfigured));
    } catch (err) {
      error(err instanceof Error ? err.message : "Lỗi tải quầy");
      setShowServiceModal(false);
    } finally {
      setServiceModalLoading(false);
    }
  };

  const handleToggleService = (serviceId: string) => {
    setSelectedServiceIds((prev) => {
      const next = new Set(prev);
      if (next.has(serviceId)) next.delete(serviceId);
      else next.add(serviceId);
      return next;
    });
  };

  const handleSaveServices = async () => {
    if (!serviceModalStaff) return;

    setServiceModalSaving(true);
    try {
      await updateStaffServices(serviceModalStaff._id, Array.from(selectedServiceIds));
      success("Cập nhật quầy thành công");
      setShowServiceModal(false);
      await fetchStaff();
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Lỗi lưu quầy";
      if (msg.includes("404") || msg.toLowerCase().includes("not found")) {
        error("API gán quầy trả 404, vui lòng kiểm tra backend.");
      } else {
        error(msg);
      }
    } finally {
      setServiceModalSaving(false);
    }
  };

  const allServices = useMemo(() => {
    const map = new Map();
    counters.forEach((counter) => {
      counter.services?.forEach((service) => {
        map.set(service._id, service);
      });
    });

    return Array.from(map.values()).sort(
      (a: any, b: any) => (a.displayOrder || 0) - (b.displayOrder || 0),
    );
  }, [counters]);

  const serviceColorMap = useMemo(() => {
    const colorMap = new Map<string, ReturnType<typeof getSequentialTagColorStyle>>();
    allServices.forEach((service: any, index: number) => {
      const color = getSequentialTagColorStyle(index);
      if (service._id) colorMap.set(service._id, color);
      if (service.id) colorMap.set(service.id, color);
    });
    return colorMap;
  }, [allServices]);

  const filteredStaff = staffList.filter((staff) => {
    const matchesSearch =
      staff.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      staff.fullName.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesCounter =
      filterCounterIds.includes("all") ||
      (filterCounterIds.includes("unassigned") && !staff.counterId) ||
      (staff.counterId && filterCounterIds.includes(staff.counterId._id));
      
    const matchesService = 
      filterServiceIds.includes("all") ||
      (filterServiceIds.includes("unassigned") && (!staff.effectiveServices || staff.effectiveServices.length === 0)) ||
      (staff.effectiveServices && staff.effectiveServices.some(s => filterServiceIds.includes(s.id || s._id)));

    const matchesStatus =
      filterStatuses.includes("all") ||
      (filterStatuses.includes("active") && staff.isActive) ||
      (filterStatuses.includes("inactive") && !staff.isActive);

    return matchesSearch && matchesCounter && matchesService && matchesStatus;
  });

  const totalPages = Math.ceil(filteredStaff.length / itemsPerPage);
  const currentItems = filteredStaff.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  );

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, filterCounterIds, filterServiceIds, filterStatuses]);

  const getCounterDisplay = (staff: Staff) => {
    if (!staff.counterId) return null;
    const matchedCounter = counters.find((counter) => counter._id === staff.counterId?._id);
    const counterCode = staff.counterId.code || matchedCounter?.code || "";
    return `${staff.counterId.name}${counterCode ? ` (${counterCode})` : ""}`;
  };

  return (
    <div className="admin-table-container">
      <div className="admin-table-header">
        <div className="font-bold text-2xl" style={{ color: "#003366" }}>
          QUẢN LÝ NHÂN VIÊN
        </div>
        <div className="admin-table-actions">
          <AdminTableFilter
            activeCount={
              (filterCounterIds.includes("all") ? 0 : filterCounterIds.length) +
              (filterServiceIds.includes("all") ? 0 : filterServiceIds.length) +
              (filterStatuses.includes("all") ? 0 : filterStatuses.length)
            }
            onReset={() => {
              setFilterCounterIds(["all"]);
              setFilterServiceIds(["all"]);
              setFilterStatuses(["all"]);
            }}
            sections={[
              {
                id: "staff-counter",
                label: "Phòng trực",
                value: filterCounterIds,
                onChange: setFilterCounterIds,
                options: [
                  { label: "Tất cả phòng", value: "all" },
                  { label: "Chưa gán phòng", value: "unassigned" },
                  ...[...counters]
                    .sort((a, b) => a.number - b.number)
                    .map((counter) => ({
                      label: `${counter.name} (${counter.code})`,
                      value: counter._id,
                    })),
                ],
              },
              {
                id: "staff-service",
                label: "Quầy trực",
                value: filterServiceIds,
                onChange: setFilterServiceIds,
                options: [
                  { label: "Tất cả quầy", value: "all" },
                  { label: "Không có quầy", value: "unassigned" },
                  ...allServices.map((service: any) => ({
                    label: `${service.name} (${service.code})`,
                    value: service._id,
                  })),
                ],
              },
              {
                id: "staff-status",
                label: "Trạng thái",
                value: filterStatuses,
                onChange: setFilterStatuses,
                options: [
                  { label: "Tất cả trạng thái", value: "all" },
                  { label: "Hoạt động", value: "active" },
                  { label: "Vô hiệu", value: "inactive" },
                ],
              },
            ]}
          />
          <input
            type="text"
            className="admin-table-search"
            placeholder="Tìm kiếm nhân viên..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button className="admin-table-btn" onClick={() => handleOpenModal()}>
            + Thêm Mới
          </button>
        </div>
      </div>

      {loading ? (
        <div className="admin-table-loading">Đang tải...</div>
      ) : (
        <table className="admin-table">
          <thead>
            <tr>
              <th>Tên đăng nhập</th>
              <th>Họ và tên</th>
              <th>Phòng trực</th>
              <th>Quầy trực</th>
              <th>Trạng thái</th>
              <th>Đăng nhập</th>
              <th>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {currentItems.map((staff) => (
              <tr key={staff._id}>
                <td>
                  <strong>{staff.username}</strong>
                </td>
                <td>{staff.fullName}</td>
                <td>
                  {staff.counterId ? (
                    getCounterDisplay(staff)
                  ) : (
                    <span style={{ color: "#999" }}>Chưa gán</span>
                  )}
                </td>
                <td>
                  {staff.effectiveServices && staff.effectiveServices.length > 0 ? (
                    <div className="table-cell-counters">
                      {staff.effectiveServices.map((service) => {
                        const serviceId = service.id || service._id;
                        const tagStyle = serviceColorMap.get(serviceId);

                        return (
                          <span
                            key={serviceId}
                            className="table-cell-tag"
                            style={{
                              background: tagStyle?.background || "#bfdbfe",
                              borderLeftColor: tagStyle?.border || "#2563eb",
                              color: tagStyle?.color || "#1e3a8a",
                            }}
                          >
                            {service.name}
                            {service.code ? ` (${service.code})` : ""}
                          </span>
                        );
                      })}
                    </div>
                  ) : staff.serviceRestrictionConfigured ? (
                    <span className="admin-empty-info">Không có quầy</span>
                  ) : (
                    <span style={{ color: "#666", fontStyle: "italic", fontSize: "0.9em" }}>
                      Tất cả (mặc định)
                    </span>
                  )}
                </td>
                <td>
                  <span
                    className={`table-cell-status ${
                      staff.isActive ? "status-true" : "status-false"
                    }`}
                  >
                    {staff.isActive ? "Hoạt động" : "Vô hiệu"}
                  </span>
                </td>
                <td>
                  {staff.lastLoginAt
                    ? new Date(staff.lastLoginAt).toLocaleString("vi-VN")
                    : "Chưa đăng nhập"}
                </td>
                <td>
                  <div className="table-actions">
                    <button
                      className="table-action-btn table-action-edit"
                      onClick={() => handleOpenModal(staff)}
                      title="Sửa"
                    >
                      <FiEdit size={18} />
                    </button>
                    <button
                      className="table-action-btn"
                      style={{ background: "transparent", color: "#000", border: "none" }}
                      onClick={() => handleOpenServiceModal(staff)}
                      title="Phân quyền quầy"
                      disabled={!staff.counterId}
                    >
                      <FiRepeat size={16} color="#000" />
                    </button>
                    <button
                      className="table-action-btn table-action-delete"
                      onClick={() => handleDelete(staff._id)}
                      title="Xóa"
                    >
                      <RiDeleteBin6Line size={18} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <div className="admin-table-footer">
        <span>Hiển thị {currentItems.length} trên tổng số {filteredStaff.length} kết quả</span>
      </div>
      {filteredStaff.length > 0 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={(page) => setCurrentPage(page)}
        />
      )}

      {showModal && (
        <div className="admin-modal">
          <div className="admin-modal-content">
            <button className="admin-modal-close" onClick={handleCloseModal}>
              ×
            </button>
            <h3>{editingId ? "Chỉnh Sửa Nhân Viên" : "Thêm Nhân Viên Mới"}</h3>

            <div className="admin-form-grid">
              <div className="admin-form-left">
                <div className="admin-form-group">
                  <label className="admin-form-label">Tên đăng nhập:</label>
                  <input
                    type="text"
                    className="admin-form-input"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    disabled={!!editingId}
                  />
                </div>

                <div className="admin-form-group">
                  <label className="admin-form-label">Mật khẩu:</label>
                  <input
                    type="password"
                    className="admin-form-input"
                    placeholder={editingId ? "Để trống nếu không đổi mật khẩu" : ""}
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  />
                </div>

                <div className="admin-form-group">
                  <label className="admin-form-label">Họ và tên:</label>
                  <input
                    type="text"
                    className="admin-form-input"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  />
                </div>
              </div>

              <div className="admin-form-right">
                <div className="admin-form-group">
                  <label className="admin-form-label">Gán phòng:</label>
                  <select
                    className="admin-form-input"
                    value={formData.counterId || ""}
                    onChange={(e) => handleFormCounterChange(e.target.value || null)}
                  >
                    <option value="">Không gán</option>
                    {counters.map((counter) => (
                      <option key={counter._id} value={counter._id}>
                        {counter.name} ({counter.code})
                      </option>
                    ))}
                  </select>

                  <div className="admin-form-hint">
                    Sau khi lưu gán phòng, hệ thống sẽ chuyển sang bước chọn quầy.
                  </div>
                </div>

                {formData.counterId && (
                  <div className="admin-form-group">
                    <label className="admin-form-label">Quầy áp dụng cho nhân viên</label>

                    {formAvailableServices.length === 0 ? (
                      <div className="admin-empty">Phòng này chưa có quầy nào.</div>
                    ) : (
                      <div className="admin-service-list">
                        {formAvailableServices.map((service) => {
                          const id = service.id || service._id;
                          const checked = formSelectedServiceIds.has(id);

                          return (
                            <label
                              key={id}
                              className={`admin-service-item ${checked ? "active" : ""}`}
                            >
                              <input
                                type="checkbox"
                                checked={checked}
                                onChange={() => handleToggleFormService(id)}
                              />
                              <div>
                                <div className="service-name">{service.name}</div>
                                <div className="service-code">{service.code}</div>
                              </div>
                            </label>
                          );
                        })}
                      </div>
                    )}

                    {formAvailableServices.length > 0 && formSelectedServiceIds.size === 0 && (
                      <div className="admin-error">Không chọn quầy nào.</div>
                    )}
                  </div>
                )}

                <div className="admin-form-group">
                  <label>
                    <input
                      type="checkbox"
                      checked={formData.isActive}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          isActive: e.target.checked,
                        })
                      }
                    />{" "}
                    Kích hoạt tài khoản
                  </label>
                </div>
              </div>
            </div>

            <div className="admin-form-actions">
              <button className="submit" onClick={handleSave}>
                Lưu
              </button>
              <button className="cancel" onClick={handleCloseModal}>
                Hủy
              </button>
            </div>
          </div>
        </div>
      )}

      <AdminConfirmDialog
        isOpen={showDeleteConfirm}
        title="Xác nhận xóa nhân viên"
        message="Bạn có chắc chắn muốn xóa nhân viên này? Hành động này không thể hoàn tác."
        onConfirm={handleConfirmDelete}
        onCancel={() => setShowDeleteConfirm(false)}
      />

      <ToastContainer toasts={toasts} onRemoveToast={removeToast} />

      {showServiceModal && serviceModalStaff && (
        <div className="admin-modal">
          <div className="admin-modal-content" style={{ maxWidth: 480 }}>
            <button className="admin-modal-close" onClick={() => setShowServiceModal(false)}>
              ×
            </button>
            <h3>Phân quyền quầy - {serviceModalStaff.fullName}</h3>

            {!serviceModalStaff.counterId && (
              <p
                style={{
                  color: "#856404",
                  background: "#fff3cd",
                  padding: "8px 12px",
                  borderRadius: 6,
                  fontSize: 14,
                }}
              >
                Nhân viên chưa được gán phòng, vui lòng gán phòng trước.
              </p>
            )}

            {serviceModalLoading ? (
              <p style={{ color: "#666", textAlign: "center", padding: 20 }}>Đang tải quầy...</p>
            ) : (
              <>
                <p style={{ fontSize: 13, color: "#555", marginBottom: 12 }}>
                  {serviceRestrictionConfigured
                    ? "Nhân viên đang áp dụng giới hạn quầy riêng. Hãy chọn rõ quầy nào được áp dụng cho nhân viên này."
                    : "Chưa cấu hình, nhân viên đang xử lý tất cả quầy của phòng."}
                </p>

                {availableServices.length === 0 ? (
                  <p style={{ color: "#999", fontStyle: "italic" }}>Phòng không có quầy nào.</p>
                ) : (
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: 10,
                      marginBottom: 20,
                    }}
                  >
                    {availableServices.map((service) => {
                      const id = service.id || service._id;
                      const checked = selectedServiceIds.has(id);

                      return (
                        <label
                          key={id}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: 10,
                            cursor: "pointer",
                            padding: "8px 12px",
                            borderRadius: 6,
                            background: checked ? "#e8f0fe" : "#f9f9f9",
                            border: `1px solid ${checked ? "#4a7fd4" : "#ddd"}`,
                          }}
                        >
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() => handleToggleService(id)}
                            style={{ width: 16, height: 16 }}
                          />
                          <div>
                            <div style={{ fontWeight: 600, fontSize: 14, color: "#003366" }}>
                              {service.name}
                            </div>
                            <div style={{ fontSize: 12, color: "#888" }}>{service.code}</div>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                )}

                <div className="admin-form-actions">
                  <button
                    className="submit"
                    onClick={handleSaveServices}
                    disabled={serviceModalSaving}
                  >
                    {serviceModalSaving ? "Đang lưu..." : "Lưu"}
                  </button>
                  <button className="cancel" onClick={() => setShowServiceModal(false)}>
                    Hủy
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
